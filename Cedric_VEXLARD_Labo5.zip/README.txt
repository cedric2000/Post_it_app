
Pour demmarer l'application il faut avoir installer python et flask.
(Tuto instalation : http://fr.openclassrooms.com/informatique/cours/creez-vos-applications-web-avec-flask/installation-et-premiers-pas)
Lancer l'application dans le terminal windows : python app.py

Le serveur tourne et est pr�s � echanger des donn�es.
Ouvrir la page index et utiliser l'application.